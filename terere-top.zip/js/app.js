/* Lógica do site: cardápio, carrinho, checkout e WhatsApp. Dados em products.js / config.js */
(function () {
  const $ = (s) => document.querySelector(s);
  const money = (n) => "R$" + n.toFixed(2).replace(".", ",");
  const round = (n) => Math.round(n * 100) / 100;

  // Adicionais viram uma categoria de produtos
  const ALL = PRODUCTS.concat(ADDONS.map((a) => ({ id: "add-" + a.id, category: "adicionais", name: a.name, price: a.price, addons: [], description: "" })));
  const byId = (id) => ALL.find((p) => p.id === id);
  const addonById = (id) => ADDONS.find((a) => a.id === id);

  /* ---------- Carrinho ---------- */
  let cart = [];
  try { cart = JSON.parse(localStorage.getItem("tt_cart") || "[]").filter((i) => byId(i.id)); } catch (e) { cart = []; }
  const save = () => { try { localStorage.setItem("tt_cart", JSON.stringify(cart)); } catch (e) {} };
  const unit = (i) => (byId(i.id).price || 0) + i.addons.reduce((s, a) => s + addonById(a).price, 0);
  const lineTotal = (i) => round(unit(i) * i.qty);
  const total = () => round(cart.reduce((s, i) => s + lineTotal(i), 0));
  const count = () => cart.reduce((s, i) => s + i.qty, 0);
  const pending = () => cart.some((i) => byId(i.id).price === null);

  function addToCart(id, opts, addons, qty) {
    const key = id + "|" + opts.join(",") + "|" + addons.slice().sort().join(",");
    const ex = cart.find((i) => i.key === key);
    if (ex) ex.qty += qty; else cart.push({ key, id, opts, addons, qty });
    save(); refreshBar(true);
  }
  function refreshBar(bump) {
    const n = count();
    $("#cartbar-info").textContent = n ? `${n} ${n === 1 ? "item" : "itens"} · ${money(total())}${pending() ? " +" : ""}` : "Nenhum item";
    if (bump) { const b = $("#cartbar"); b.classList.remove("bump"); void b.offsetWidth; b.classList.add("bump"); }
  }
  function toast(t) { const el = $("#toast"); el.textContent = t; el.classList.add("on"); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove("on"), 1400); }

  /* ---------- Cardápio ---------- */
  function cardHTML(p) {
    const price = p.price === null ? `<span class="price tbd">Consultar valor</span>` : `<span class="price">${money(p.price)}</span>`;
    const btn = `<button class="add" data-add="${p.id}">+ ADICIONAR</button>`;
    if (!p.image) return `<article class="card noimg"><div class="row"><h3>${p.name}</h3><div class="buy">${price}${btn}</div></div></article>`;
    return `<article class="card"><img src="img/${p.image}.webp" alt="${p.name}" width="104" height="104" loading="lazy">
      <div><h3>${p.name}</h3>${p.description ? `<p>${p.description}</p>` : ""}<div class="buy">${price}${btn}</div></div></article>`;
  }
  function buildMenu() {
    const menu = $("#menu");
    CATEGORIES.forEach((c) => {
      const items = ALL.filter((p) => p.category === c.id);
      let html = `<section id="${c.id}"><h2 class="h">${c.name}</h2><p class="sub">${c.sub}</p>`;
      const groups = [...new Set(items.map((p) => p.group || ""))];
      groups.forEach((g) => {
        if (g) html += `<h3 class="group">${g}</h3>`;
        html += `<div class="list">${items.filter((p) => (p.group || "") === g).map(cardHTML).join("")}</div>`;
      });
      menu.insertAdjacentHTML("beforeend", html + "</section>");
    });
    $("#featured").innerHTML = FEATURED.map((id) => cardHTML(byId(id))).join("");
    $("#nav").innerHTML = `<a href="#inicio">INÍCIO</a>` + CATEGORIES.map((c) => `<a href="#${c.id}">${c.name}</a>`).join("");
    $("#cats").innerHTML = CATEGORIES.map((c) => `<a href="#${c.id}"><span>${c.emoji}</span>${c.name}</a>`).join("");
  }
  // destaca a categoria visível no menu
  function spy() {
    const links = [...document.querySelectorAll("#nav a")];
    const io = new IntersectionObserver((es) => es.forEach((e) => {
      if (e.isIntersecting) links.forEach((a) => {
        const on = a.getAttribute("href") === "#" + e.target.id; a.classList.toggle("on", on);
        if (on) a.scrollIntoView({ inline: "center", block: "nearest" });
      });
    }), { rootMargin: "-30% 0px -60% 0px" });
    document.querySelectorAll("#inicio, main section").forEach((s) => io.observe(s));
  }

  /* ---------- Sheet ---------- */
  const open = (html) => { $("#sheet").innerHTML = html; $("#overlay").hidden = false; document.body.style.overflow = "hidden"; $("#sheet").scrollTop = 0; };
  const close = () => { $("#overlay").hidden = true; document.body.style.overflow = ""; };
  $("#overlay").addEventListener("click", (e) => { if (e.target.id === "overlay" || e.target.closest("[data-close]")) close(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") close(); });

  function productSheet(id) {
    const p = byId(id), o = p.options;
    const sel = { opts: [], addons: [], qty: 1 };
    const draw = () => {
      const addTotal = sel.addons.reduce((s, a) => s + addonById(a).price, 0);
      const t = round(((p.price || 0) + addTotal) * sel.qty);
      let h = `<div class="sh-head"><h3>${p.name}</h3><button class="x" data-close aria-label="Fechar">✕</button></div>
        ${p.description ? `<p class="note">${p.description}</p>` : ""}`;
      if (o) h += `<h4>${o.title}</h4>` + o.choices.map((c) => optBtn("o", c, sel.opts.includes(c), "")).join("") + `<p class="err" id="err" hidden></p>`;
      if (p.addons.length) h += `<h4>Adicionais</h4>` + p.addons.map((a) => optBtn("a", a, sel.addons.includes(a), "+ " + money(addonById(a).price), addonById(a).name)).join("");
      h += `<div class="sh-foot"><div class="qty"><button data-q="-1" aria-label="Diminuir">−</button><b>${sel.qty}</b><button data-q="1" aria-label="Aumentar">+</button></div>
        <button class="btn btn-gold" data-ok>${p.price === null ? "ADICIONAR" : "ADICIONAR " + money(t)}</button></div>`;
      const sc = $("#sheet").scrollTop; open(h); $("#sheet").scrollTop = sc;
    };
    const optBtn = (k, v, on, price, label) => `<button class="opt ${on ? "on" : ""}" data-${k}="${v}" aria-pressed="${on}"><span class="chk">${on ? "✓" : ""}</span><span>${label || v}</span><small>${price}</small></button>`;
    draw();
    $("#sheet").onclick = (e) => {
      const t = e.target.closest("button"); if (!t) return;
      if (t.dataset.o) {
        const i = sel.opts.indexOf(t.dataset.o);
        if (i >= 0) sel.opts.splice(i, 1); else { sel.opts.push(t.dataset.o); if (sel.opts.length > o.pick) sel.opts.shift(); }
        draw();
      } else if (t.dataset.a) {
        const i = sel.addons.indexOf(t.dataset.a); if (i >= 0) sel.addons.splice(i, 1); else sel.addons.push(t.dataset.a); draw();
      } else if (t.dataset.q) { sel.qty = Math.max(1, Math.min(20, sel.qty + +t.dataset.q)); draw();
      } else if (t.hasAttribute("data-ok")) {
        if (o && sel.opts.length !== o.pick) { const er = $("#err"); er.hidden = false; er.textContent = o.pick > 1 ? `Escolha ${o.pick} opções.` : "Escolha uma opção."; er.scrollIntoView({ block: "center" }); return; }
        addToCart(id, sel.opts, sel.addons, sel.qty); close(); toast("Adicionado ao pedido");
      }
    };
  }

  /* ---------- Carrinho + checkout ---------- */
  function cartSheet() {
    if (!cart.length) { open(`<div class="sh-head"><h3>Seu pedido</h3><button class="x" data-close aria-label="Fechar">✕</button></div><p class="empty">Seu pedido está vazio.<br>Escolha um produto para começar.</p>`); $("#sheet").onclick = null; return; }
    let h = `<div class="sh-head"><h3>Seu pedido</h3><button class="x" data-close aria-label="Fechar">✕</button></div>`;
    cart.forEach((i, idx) => {
      const p = byId(i.id);
      const det = [i.opts.join(", "), ...i.addons.map((a) => "+ " + addonById(a).name)].filter(Boolean).join(" · ");
      h += `<div class="item"><div class="top"><span>${p.name}</span><span>${p.price === null ? "a confirmar" : money(lineTotal(i))}</span></div>
        ${det ? `<p class="d">${det}</p>` : ""}<p class="d">${p.price === null ? "Valor a confirmar" : money(unit(i)) + " cada"}</p>
        <div class="ctl"><div class="qty"><button data-c="${idx}" data-d="-1" aria-label="Diminuir">−</button><b>${i.qty}</b><button data-c="${idx}" data-d="1" aria-label="Aumentar">+</button></div>
        <button class="trash" data-r="${idx}" aria-label="Remover ${p.name}">🗑</button></div></div>`;
    });
    h += `<div class="total"><span>TOTAL</span><b>${money(total())}</b></div>${pending() ? `<p class="note">Há item(ns) com valor a confirmar, não incluído(s) no total.</p>` : ""}
      <button class="btn btn-gold" data-go style="margin-top:16px">FINALIZAR PEDIDO</button><button class="link" data-close>Continuar escolhendo</button>`;
    const sc = $("#sheet").scrollTop; open(h); $("#sheet").scrollTop = sc;
    $("#sheet").onclick = (e) => {
      const t = e.target.closest("button"); if (!t) return;
      if (t.dataset.c !== undefined) { const i = cart[+t.dataset.c]; i.qty = Math.max(1, Math.min(50, i.qty + +t.dataset.d)); save(); refreshBar(); cartSheet(); }
      else if (t.dataset.r !== undefined) { cart.splice(+t.dataset.r, 1); save(); refreshBar(); cartSheet(); }
      else if (t.hasAttribute("data-go")) checkoutSheet();
    };
  }

  const WA_ICON = `<svg viewBox="0 0 32 32" fill="currentColor" aria-hidden="true"><path d="M16 3C9 3 3.4 8.6 3.4 15.5c0 2.3.6 4.4 1.7 6.3L3 29l7.4-1.9c1.8 1 3.800 1.500 5.600 1.500 7 0 12.600-5.600 12.600-12.500S23 3 16 3zm0 22.900c-1.800 0-3.500-.5-5-1.400l-.4-.2-4.400 1.100 1.200-4.300-.3-.4a10.300 10.300 0 0 1-1.600-5.500C5.500 9.800 10.200 5.200 16 5.200S26.500 9.800 26.500 15.500 21.800 25.900 16 25.900zm5.700-7.700c-.3-.2-1.800-.9-2.100-1s-.5-.2-.7.200-.8 1-1 1.200-.4.200-.7 0a8.400 8.400 0 0 1-4.200-3.700c-.3-.6.300-.5.900-1.700.1-.2 0-.4 0-.5l-1-2.300c-.2-.6-.5-.5-.7-.5h-.6a1.200 1.200 0 0 0-.9.400 3.800 3.800 0 0 0-1.200 2.800c0 1.700 1.200 3.300 1.400 3.500s2.400 3.700 5.900 5.200c2.200.9 3 1 4.100.8.700-.1 2-.8 2.300-1.600s.3-1.500.2-1.600-.3-.2-.6-.4z"/></svg>`;
  let pay = null;
  function checkoutSheet() {
    let h = `<div class="sh-head"><h3>Finalizar pedido</h3><button class="x" data-close aria-label="Fechar">✕</button></div>
      <div class="total"><span>TOTAL</span><b>${money(total())}</b></div>${pending() ? `<p class="note">Itens com valor a confirmar não estão no total.</p>` : ""}
      <label class="f" for="f-name">Nome</label><input class="i" id="f-name" autocomplete="name"><p class="err" id="e-name" hidden>Informe seu nome.</p>
      <label class="f" for="f-addr">Endereço</label><input class="i" id="f-addr" autocomplete="street-address" placeholder="Rua e número"><p class="err" id="e-addr" hidden>Informe o endereço.</p>
      <label class="f" for="f-bairro">Bairro</label><input class="i" id="f-bairro"><p class="err" id="e-bairro" hidden>Informe o bairro.</p>
      <label class="f">Forma de pagamento</label><div class="pay">${["PIX", "DINHEIRO", "CARTÃO"].map((m) => `<button type="button" class="opt ${pay === m ? "on" : ""}" data-pay="${m}" aria-pressed="${pay === m}">${m}</button>`).join("")}</div><p class="err" id="e-pay" hidden>Escolha a forma de pagamento.</p>
      <div id="troco" ${pay === "DINHEIRO" ? "" : "hidden"}><label class="f" for="f-troco">Precisa de troco?</label><input class="i" id="f-troco" placeholder="Ex.: troco para R$50"></div>
      <label class="f" for="f-obs">Observação <span style="opacity:.6">(opcional)</span></label><textarea class="i" id="f-obs" rows="2" placeholder="Ex.: sem cebola"></textarea>
      <button class="btn btn-wa" data-send>${WA_ICON}FINALIZAR PEDIDO NO WHATSAPP</button><button class="link" data-back>Voltar ao pedido</button>`;
    open(h);
    $("#sheet").onclick = (e) => {
      const t = e.target.closest("button"); if (!t) return;
      if (t.dataset.pay) { pay = t.dataset.pay; document.querySelectorAll("[data-pay]").forEach((b) => { const on = b.dataset.pay === pay; b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); }); $("#troco").hidden = pay !== "DINHEIRO"; $("#e-pay").hidden = true; }
      else if (t.hasAttribute("data-back")) cartSheet();
      else if (t.hasAttribute("data-send")) send();
    };
  }

  const EMO = { terere: "🌿", burguer: "🍔", combos: "🎁", porcoes: "🍟", bebidas: "🥤", adicionais: "➕" };
  function buildMessage(f) {
    const L = [`Olá, ${STORE_NAME}! 👑`, "", "Quero fazer um pedido:", ""];
    cart.forEach((i) => {
      const p = byId(i.id);
      L.push(`${EMO[p.category]} ${p.name.toUpperCase()}`, `Quantidade: ${i.qty}`);
      if (i.opts.length) L.push(`Opção: ${i.opts.join(", ")}`);
      L.push(p.price === null ? "Valor: a confirmar" : money(round(p.price * i.qty)));
      if (i.addons.length) {
        L.push("", "➕ Adicionais:");
        i.addons.forEach((a) => L.push(`- ${addonById(a).name} + ${money(round(addonById(a).price * i.qty))}`));
      }
      L.push("");
    });
    L.push(`💰 TOTAL: ${money(total())}${pending() ? " (+ itens a confirmar)" : ""}`, "", `👤 Nome: ${f.name}`, "", "📍 Endereço:", f.addr, f.bairro, "", `💳 Pagamento: ${pay}`);
    if (pay === "DINHEIRO" && f.troco) L.push(`💵 Troco: ${f.troco}`);
    if (f.obs) L.push("", "📝 Observação:", f.obs);
    return L.join("\n");
  }
  function send() {
    const f = { name: $("#f-name").value.trim(), addr: $("#f-addr").value.trim(), bairro: $("#f-bairro").value.trim(), troco: ($("#f-troco") || {}).value?.trim(), obs: $("#f-obs").value.trim() };
    let ok = true;
    [["name", "e-name"], ["addr", "e-addr"], ["bairro", "e-bairro"]].forEach(([k, e]) => { const bad = !f[k]; $("#" + e).hidden = !bad; if (bad) ok = false; });
    if (!pay) { $("#e-pay").hidden = false; ok = false; }
    if (!cart.length) return;
    if (!ok) { const first = document.querySelector(".err:not([hidden])"); if (first) first.scrollIntoView({ block: "center" }); return; }
    window.location.href = "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encodeURIComponent(buildMessage(f));
  }

  /* ---------- Eventos ---------- */
  document.addEventListener("click", (e) => {
    const b = e.target.closest("[data-add]"); if (!b) return;
    const p = byId(b.dataset.add);
    if (p.options || p.addons.length) productSheet(p.id);
    else { addToCart(p.id, [], [], 1); toast("Adicionado ao pedido"); }
  });
  $("#cartbar").onclick = cartSheet;

  buildMenu(); refreshBar(); spy();
})();
