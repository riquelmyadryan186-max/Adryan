/* CONFIGURAÇÃO GERAL — número do WhatsApp e nome da loja (único lugar) */
const WHATSAPP_NUMBER = "5568999668731";
const STORE_NAME = "Tereré Top";
