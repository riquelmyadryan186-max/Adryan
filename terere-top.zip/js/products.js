/* ==========================================================
   CARDÁPIO — altere preços, produtos e adicionais AQUI.
   price: número em reais. price: null = "consultar valor".
   addons: lista de ids de ADDONS (ou [] para nenhum).
   options: {title, pick, choices} para escolher sabor/variação.
   ========================================================== */
const CATEGORIES = [
  { id: "terere",  name: "TERERÉ",    emoji: "🌿", sub: "Tereré" },
  { id: "burguer", name: "BURGUER",   emoji: "🍔", sub: "Hambúrgueres artesanais" },
  { id: "combos",  name: "COMBOS",    emoji: "🎁", sub: "Burguer combos" },
  { id: "porcoes", name: "PORÇÕES",   emoji: "🍟", sub: "Porções" },
  { id: "bebidas", name: "BEBIDAS",   emoji: "🥤", sub: "Bebidas" },
  { id: "adicionais", name: "ADICIONAIS", emoji: "➕", sub: "Deixe seu lanche do seu jeito" },
];

// Adicionais (também aparecem como categoria)
const ADDONS = [
  { id: "batata", name: "Batata", price: 5 }, { id: "tomate", name: "Tomate", price: 2 },
  { id: "alface", name: "Alface", price: 2 }, { id: "bacon", name: "Bacon", price: 5 },
  { id: "cebola", name: "Cebola", price: 2 }, { id: "azeitona", name: "Azeitona", price: 2 },
  { id: "queijo", name: "Queijo", price: 2 }, { id: "banana", name: "Banana", price: 3 },
  { id: "cebola-car", name: "Cebola caramelizada", price: 3 }, { id: "molho-rose", name: "Molho rose", price: 2 },
  { id: "maionese", name: "Maionese", price: 2 }, { id: "alho", name: "Alho", price: 2 },
  { id: "barbecue", name: "Barbecue", price: 2 }, { id: "cheddar", name: "Cheddar", price: 3 },
  { id: "calabresa", name: "Calabresa", price: 5 }, { id: "ovos", name: "Ovos", price: 2 },
  { id: "carne", name: "Carne", price: 10 }, { id: "suco", name: "Suco", price: 1.5 },
  { id: "limao", name: "Limão", price: 3 },
];

// Grupos de adicionais reutilizáveis (ajuste por produto quando quiser)
const ADDON_SETS = {
  burguer: ["bacon", "cheddar", "ovos", "carne", "queijo", "tomate", "alface", "cebola", "cebola-car", "banana", "azeitona", "molho-rose", "maionese", "alho", "barbecue", "calabresa", "batata"],
  porcao: ["molho-rose", "maionese", "barbecue", "cheddar", "limao", "bacon"],
  terere: ["suco", "limao"],
  nenhum: [],
};

const PRODUCTS = [
  // ---- TERERÉ ----
  { id: "garrafa-25", category: "terere", name: "Garrafa 2,5L", price: 18, image: "garrafa25", addons: ADDON_SETS.terere,
    description: "Água, gelo, suco ou limão espremido, 1 copo c/ erva" },
  { id: "torre-25", category: "terere", name: "Torre 2,5L", price: 25, image: "torre25", addons: ADDON_SETS.terere,
    description: "Água, gelo, suco ou limão espremido, 2 copos c/ erva" },
  { id: "torre-35", category: "terere", name: "Torre 3,5L", price: 30, image: "torre35", addons: ADDON_SETS.terere,
    description: "Água, gelo, suco ou limão espremido, 2 copos c/ erva" },
  { id: "garrafa-9", category: "terere", name: "Garrafa 9L", price: 45, image: "garrafa9", addons: ADDON_SETS.terere,
    description: "Água, gelo, suco ou limão espremido, 4 copos c/ erva" },
  // Torres especiais — preço não informado no cardápio: preencha em price
  { id: "sp-suco", group: "TORRES ESPECIAIS", category: "terere", name: "Torre com suco de limão", price: null, image: "sp-suco", addons: [], description: "" },
  { id: "sp-limao", group: "TORRES ESPECIAIS", category: "terere", name: "Torre só com limão espremido", price: null, image: "sp-limao", addons: [], description: "" },
  { id: "sp-agua", group: "TORRES ESPECIAIS", category: "terere", name: "Torre só com água e gelo", price: null, image: "sp-agua", addons: [], description: "" },
  { id: "sp-energetico", group: "TORRES ESPECIAIS", category: "terere", name: "Torre com energético", price: null, image: "sp-energetico", addons: [], description: "" },
  // Reposições
  { id: "rep-copo", group: "REPOSIÇÕES", category: "terere", name: "Copo c/ erva", price: 5, addons: [], description: "" },
  { id: "rep-25", group: "REPOSIÇÕES", category: "terere", name: "Reposição 2,5L", price: 8, addons: [], description: "Água, gelo, suco ou limão espremido" },
  { id: "rep-35", group: "REPOSIÇÕES", category: "terere", name: "Reposição 3,5L", price: 10, addons: [], description: "Água, gelo, suco ou limão espremido" },
  { id: "rep-9", group: "REPOSIÇÕES", category: "terere", name: "Reposição 9L", price: 15, addons: [], description: "Água, gelo, suco ou limão espremido" },

  // ---- BURGUER ----
  { id: "mustamburguer", category: "burguer", name: "Mustamburguer", price: 18, image: "musta", addons: ADDON_SETS.burguer,
    description: "Pão brioche, queijo mussarela, carne 120g, molho especial." },
  { id: "lets-burguer", category: "burguer", name: "Let's Burguer", price: 25, image: "lets", addons: ADDON_SETS.burguer,
    description: "Pão brioche, carne 120g, bacon, queijo cheddar, tomate, molho especial." },
  { id: "banana-bacon", category: "burguer", name: "Banana Bacon", price: 27, image: "banana", addons: ADDON_SETS.burguer,
    description: "Pão brioche, carne 120g, bacon, queijo cheddar, banana frita, molho especial." },
  { id: "xtremeburguer", category: "burguer", name: "Xtremeburguer", price: 22, image: "xtreme", addons: ADDON_SETS.burguer,
    description: "Pão brioche, carnes 120g, queijo, queijo cheddar, alface, molho especial." },
  { id: "costela-premium", category: "burguer", name: "Costela Premium", price: 34.99, image: "costela", addons: ADDON_SETS.burguer,
    description: "Pão brioche, carne 120g, queijo mussarela, costela desfiada na chapa, BBQ, cebola caramelizada." },
  { id: "fireburguer", category: "burguer", name: "Fireburguer", price: 30, image: "fire", addons: ADDON_SETS.burguer,
    description: "Pão brioche, 2 carnes 120g, duplo queijo cheddar, molho especial." },
  { id: "topburguer", category: "burguer", name: "Topburguer", price: 32, image: "top", addons: ADDON_SETS.burguer,
    description: "Pão brioche, carne 120g, queijo mussarela, bacon, calabresa, tomate, molho especial + 100g de batata frita." },

  // ---- COMBOS ----
  { id: "combo-artesanal", category: "combos", name: "Combo Artesanal", price: 19.99, image: "artesanal", addons: [], description: "Mustamburguer + Guaraná 200ml" },
  { id: "combo-kids", category: "combos", name: "Combo Kids", price: 25, image: "kids", addons: [], description: "Mustamburguer + Batata 100g + Guaraná 200ml" },
  { id: "combo-casal", category: "combos", name: "Combo Casal", price: 50, image: "casal", addons: [], description: "Let's Burguer + Fireburguer + 2 Guaraná 200ml" },
  { id: "combo-top", category: "combos", name: "Combo Top", price: 80, image: "combo-top", addons: [], description: "3 Mustamburguer + Porção de batata + Coca-Cola 1L" },

  // ---- PORÇÕES ----
  { id: "batata-p", category: "porcoes", name: "Batata Frita P", price: 8, image: "batata-p", addons: ADDON_SETS.porcao, description: "100g" },
  { id: "batata", category: "porcoes", name: "Batata Frita", price: 25, image: "batata", addons: ADDON_SETS.porcao, description: "400g + molho rose com maionese caseira" },
  { id: "aneis", category: "porcoes", name: "Anéis de Cebola", price: 35, image: "aneis", addons: ADDON_SETS.porcao, description: "400g + molho rose com maionese caseira" },
  { id: "calabresa", category: "porcoes", name: "Calabresa", price: 30, image: "calabresa", addons: ADDON_SETS.porcao, description: "400g, calabresa acebolada feita na chapa" },
  { id: "tiras", category: "porcoes", name: "Tiras de Carne", price: 35, image: "tiras", addons: ADDON_SETS.porcao, description: "400g, maminha feita na chapa, acompanha limão." },
  { id: "calabresa-fritas", category: "porcoes", name: "Calabresa c/ Fritas", price: 50, image: "calabresa-fritas", addons: ADDON_SETS.porcao, description: "800g, calabresa acebolada + batata frita, molho rose." },
  { id: "tiras-fritas", category: "porcoes", name: "Tiras de Carne c/ Fritas", price: 55, image: "tiras-fritas", addons: ADDON_SETS.porcao, description: "800g, maminha feita na chapa + batata frita, limão, molho rose." },
  { id: "top-fritas", category: "porcoes", name: "Top Fritas Família", price: 80, image: "familia", addons: ADDON_SETS.porcao, description: "1,200kg, batata frita, tiras de carne, calabresa acebolada, limão, molho rose." },
  { id: "mix-amendoim", category: "porcoes", name: "Mix Amendoim", price: 10, image: "amendoim", addons: [],
    description: "Acompanha 2 sabores de amendoim.",
    options: { title: "Escolha 2 sabores", pick: 2, choices: ["Tradicional", "Cebola", "Apimentado"] } },
  { id: "salgadinhos", category: "porcoes", name: "Salgadinhos", price: 20, image: "salgadinhos", addons: [], description: "Diversos sabores — 25 unidades" },

  // ---- BEBIDAS ----
  { id: "agua-gas", category: "bebidas", name: "Água c/ Gás", price: 5, image: "agua-gas", addons: [], description: "" },
  { id: "agua", category: "bebidas", name: "Água Mineral", price: 3, image: "mineral", addons: [], description: "" },
  { id: "refri-lata", category: "bebidas", name: "Refri Lata", price: 6, image: "lata", addons: [], description: "",
    options: { title: "Escolha o sabor", pick: 1, choices: ["Coca-Cola", "Coca-Cola Zero", "Fanta Laranja", "Guaraná"] } },
  { id: "refri-1l", category: "bebidas", name: "Refrigerante 1L", price: 10, image: "ref1l", addons: [], description: "" },
  { id: "refri-2l", category: "bebidas", name: "Refrigerante 2L", price: 15, image: "ref2l", addons: [], description: "" },
  { id: "kina", category: "bebidas", name: "Energético Kina 2L", price: 15, image: "kina", addons: [], description: "" },
  { id: "suco-natural", category: "bebidas", name: "Suco Natural", price: 10, image: "suco-natural", addons: [], description: "",
    options: { title: "Escolha o sabor", pick: 1, choices: ["Abacaxi", "Abacaxi c/ hortelã", "Graviola", "Cupuaçu", "Maracujá", "Acerola", "Laranja"] } },
  { id: "suco-top", category: "bebidas", name: "Suco Top", price: 10, image: "suco-top", addons: [], description: "Água c/ gás, limão e sal" },
];

// Produtos em destaque na Home (ids)
const FEATURED = ["topburguer", "torre-25", "top-fritas", "combo-casal"];
